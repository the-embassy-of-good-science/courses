function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bC4XsfnUP0":
        Script1();
        break;
      case "5YC8JLWo5kC":
        Script2();
        break;
      case "5j0I6ISeqJ1":
        Script3();
        break;
      case "6VZNhamdoCI":
        Script4();
        break;
      case "6aTZWXGpbCx":
        Script5();
        break;
      case "6BOkw36pAtK":
        Script6();
        break;
      case "6LxOuwAKazw":
        Script7();
        break;
      case "66XVaywTihr":
        Script8();
        break;
      case "6U2XBp3bTK8":
        Script9();
        break;
      case "5jOg8KDfmiI":
        Script10();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script2()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script3()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script4()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script5()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script6()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script7()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script8()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script9()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script10()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

