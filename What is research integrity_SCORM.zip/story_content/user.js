function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5t3dGtPCnZT":
        Script1();
        break;
      case "6rHAkBMqIBl":
        Script2();
        break;
      case "5ncDTQL6reK":
        Script3();
        break;
      case "66gQ3ryArXg":
        Script4();
        break;
      case "6NCJYETWQLh":
        Script5();
        break;
      case "6QHtGJp7gLl":
        Script6();
        break;
      case "5kgFVdRQ9IB":
        Script7();
        break;
      case "5z2xT4lhQHH":
        Script8();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script2()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script3()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script4()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script5()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script6()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script7()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script8()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

