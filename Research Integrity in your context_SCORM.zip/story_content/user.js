function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5unbjEuZNzb":
        Script1();
        break;
      case "6gdBNZRoAG5":
        Script2();
        break;
      case "6I1PvGjnnn0":
        Script3();
        break;
      case "69Mz1QQu7F3":
        Script4();
        break;
      case "5n6W8DCsUMp":
        Script5();
        break;
      case "6aKNTMVtCCi":
        Script6();
        break;
      case "65ESewc9CYr":
        Script7();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script2()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script3()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script4()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script5()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script6()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script7()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

