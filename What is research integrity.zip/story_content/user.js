function ExecuteScript(strId)
{
  switch (strId)
  {
      case "63P20y8CCqD":
        Script1();
        break;
      case "6YcuNmff4pJ":
        Script2();
        break;
      case "6gh4cjl8lIb":
        Script3();
        break;
      case "6P1Jwjzq53p":
        Script4();
        break;
      case "61x2U374gyT":
        Script5();
        break;
      case "5dBJV96Yrbd":
        Script6();
        break;
      case "6ALKZokIAQQ":
        Script7();
        break;
      case "5krVmk8OrVx":
        Script8();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script2()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script3()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script4()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script5()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script6()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script7()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script8()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

