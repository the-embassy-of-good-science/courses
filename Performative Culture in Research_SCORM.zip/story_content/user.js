function ExecuteScript(strId)
{
  switch (strId)
  {
      case "60Qj7yGJUZ8":
        Script1();
        break;
      case "5qaDqT6a5nH":
        Script2();
        break;
      case "6TRsDiJm4yI":
        Script3();
        break;
      case "68nkSiM0H1R":
        Script4();
        break;
      case "6kpYTwqGJN1":
        Script5();
        break;
      case "5hYQUrpuqWZ":
        Script6();
        break;
      case "5n7X87pALJj":
        Script7();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script2()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script3()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script4()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script5()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script6()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

function Script7()
{
  var player = GetPlayer();

var numValue = player.GetVar("Pagecountpercentage");
var JSRoundedNum = numValue.toFixed(0);
player.SetVar("Pagecountpercentage",JSRoundedNum);
}

